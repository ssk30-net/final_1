# elephant > 2022-07-18 2:57pm
https://universe.roboflow.com/object-detection/elephant-oqa00

Provided by Roboflow
License: MIT

